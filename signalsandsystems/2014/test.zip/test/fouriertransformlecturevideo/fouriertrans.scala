import numbers.finite.Complex
import numbers.finite.PolarComplex
import numbers.finite.RectComplex
import sounder.FileIO.MonoWavReader
import sounder.Sounder._
import sounder.Util._
import scala.math.sin
import scala.math.abs
import scala.math.sqrt
import scala.math.min
import scala.math.max
import scala.math.floor
import scala.math.round
import scala.math.ceil
import scala.math.pow
import scala.math.Pi

print("Reading file audio.wav")
val wavereader = new MonoWavReader("audio.wav") //read samples into array
val R = wavereader.sampleRate //sample rate
val P = 1.0/R //sample period
val c = wavereader.toArray //read samples to array c
println("File contains " + c.size + " samples at rate " + R)

//uncomment to play back samples (takes one minute)
//playSamples(c,R)

//the discrete Fourier transform of samples c
def Dc(f : Double) = c.indices.foldLeft(Complex.zero)( (s, n) => s + PolarComplex(1,-2*Pi*n*f) * c(n) )

def Fx(f : Double) = if( abs(f) < R/2 ) Dc(P*f)*P else Complex.zero


val starttime = (new java.util.Date).getTime; //record the amount of time this takes
//write output to files
{
  println("Writing Fourier transform of samples to ft.csv")
  val fmin = -12000.0
  val fmax = 12000.0
  val fstep = 20.0
  val file = new java.io.FileWriter("ft.csv")
  for(f <- fmin to fmax by fstep) { //fairly high resolution plot of spectrum
    val Fxf = Fx(f) //compute the Fourier transform
    //write out magnitude and phase
    file.write(f.toString.replace('E', 'e') + "\t" + 
      Fxf.magnitude.toString.replace('E', 'e') + "\t" +
      mod2pi(Fxf.angle).toString.replace('E', 'e') + "\n")
    print(".") //this takes a while so print dots as we compute each point
  }
  file.close
}

val endtime = (new java.util.Date).getTime;
println
println("Scala finished in " + ((endtime-starttime)/1000.0) + " seconds.")
