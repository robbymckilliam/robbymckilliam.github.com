CP=../lib/Sounder.jar:../lib/bignums.jar:../lib/JTransforms-3.0.jar:../lib/ScalaNumbers.jar:../lib/JLargeArrays-1.2.jar
scala -nocompdaemon -cp $CP fouriertrans.scala
